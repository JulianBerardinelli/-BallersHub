"use client";

import * as React from "react";

type Props = {
  /** "pro" (azul) | "pro_plus" (dorado) */
  variant?: "pro" | "pro_plus";
  size?: number;
  className?: string;
  title?: string;
};

export default function VerifiedBadge({
  variant = "pro",
  size = 18,
  className,
  title,
}: Props) {
  const id = React.useId();
  const gradId = `bhBadgeGrad-${variant}-${id}`;

  const stops =
    variant === "pro_plus"
      ? [
          { offset: "0", color: "#FAD961" }, // gold → orange
          { offset: "1", color: "#F76B1C" },
        ]
      : [
          { offset: "0", color: "#2aa4f4" }, // blue → deep blue
          { offset: "1", color: "#007ad9" },
        ];

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      className={className}
      aria-hidden={title ? undefined : true}
      role={title ? "img" : "presentation"}
    >
      {title ? <title>{title}</title> : null}
      <defs>
        <linearGradient
          id={gradId}
          x1="24"
          x2="24"
          y1="3.999"
          y2="43.001"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset={stops[0].offset} stopColor={stops[0].color} />
          <stop offset={stops[1].offset} stopColor={stops[1].color} />
        </linearGradient>
      </defs>

      {/* Burst */}
      <path
        fill={`url(#${gradId})`}
        d="M43.466,25.705l-2.599-4.259l1.293-4.817c0.187-0.694-0.146-1.424-0.793-1.738l-4.488-2.178
        l-1.518-4.752c-0.219-0.686-0.888-1.114-1.607-1.033l-4.953,0.594l-3.846-3.178c-0.555-0.459-1.355-0.459-1.91,0l-3.846,3.178
        l-4.953-0.594c-0.717-0.081-1.389,0.348-1.607,1.033l-1.518,4.752l-4.488,2.178c-0.646,0.314-0.979,1.044-0.793,1.738l1.293,4.817
        l-2.599,4.259c-0.375,0.614-0.261,1.408,0.271,1.892l3.693,3.354l0.116,4.987c0.018,0.719,0.542,1.325,1.252,1.444l4.92,0.825
        l2.795,4.133c0.403,0.595,1.172,0.822,1.833,0.538L24,40.913l4.585,1.966C28.776,42.961,28.977,43,29.175,43
        c0.486,0,0.957-0.236,1.243-0.659l2.795-4.133l4.92-0.825c0.71-0.119,1.234-0.726,1.252-1.444l0.116-4.987l3.693-3.354
        C43.727,27.113,43.841,26.319,43.466,25.705z"
      />
      {/* Check */}
      <path
        fill="#fff"
        d="M21.814,31c-0.322,0-0.646-0.104-0.92-0.316l-4.706-3.66c-0.436-0.339-0.514-0.967-0.175-1.403
        l0.614-0.789c0.339-0.436,0.967-0.514,1.403-0.175l3.581,2.785l7.086-8.209c0.361-0.418,0.992-0.464,1.41-0.104l0.757,0.653
        c0.418,0.361,0.464,0.992,0.104,1.41l-8.017,9.289C22.655,30.822,22.236,31,21.814,31z"
      />
    </svg>
  );
}
